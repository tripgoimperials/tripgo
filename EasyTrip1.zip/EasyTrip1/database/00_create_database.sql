-- Run this FIRST. Deletes any old easytrip database and creates a fresh one.
DROP DATABASE IF EXISTS easytrip;
CREATE DATABASE easytrip CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
